# Kentik Alert Notification Plugin for Ansible Event Driven Ansible

This event source plugin from Kentik accepts alert notification JSON and works in conjunction with Ansible EDA rulebooks to allow users to automate changes to their environment.

## Requirements
* Kentik portal account
* Ansible Automation Platform with EDA Controller instance

## Example rulebook
TODO

## Licensing
We are using GPL 3.0 as our default.

## Additional Questions/Remarks

If you do have additional questions/remarks, feel free to reach out to Kentik support (support@kentik.com), via email.

If you think this template did not solve all your problems, please also let us know, either with a message or a pull request.
Together we can improve this template to make it easier for our future projects.