# Kentik Ansible EDA Source Plugin Release Notes

**Topics**
- <a href="#v1-0-6">v1\.0\.6</a>

<a id="v1-0-6"></a>
## v1\.0\.6

