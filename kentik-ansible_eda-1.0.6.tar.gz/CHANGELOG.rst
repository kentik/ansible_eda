==============================================
Kentik Ansible EDA Source Plugin Release Notes
==============================================

.. contents:: Topics

v1.0.6
======

